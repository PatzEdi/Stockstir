.. _installation:

*************
Installation
*************

To install Stockstir, you need to run the following command in your terminal:

.. code-block:: console

   $ pip3 install Stockstir